"""Crypto Signal Bot — az AI Crypto Tracker jelzéseit posztolja Discordra,
és interaktív slash parancsokat ad a tracker helyi adataiból.

Indítás:  python bot.py   (a .venv-ből)  ·  vagy:  ./run.sh
"""
import logging

import discord
from discord import app_commands
from discord.ext import commands, tasks

import config
import tracker_data as td

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("crypto-signal-bot")

COLOR_BUY = 0x16C784
COLOR_SELL = 0xEA3943
COLOR_HOLD = 0xE0A43A
COLOR_INFO = 0x2F6FED

BRAND = "AI Crypto Tracker"
TRACKER_REPO = "Botirocky/ai-crypto-tracker"
ICON_URL = f"https://raw.githubusercontent.com/{TRACKER_REPO}/main/assets/icon.png"
DECISION_LABEL = {"buy": "VÉTEL", "sell": "ELADÁS", "hold": "VÁRJ"}

def _fmt(value):
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "—"
    a = abs(v)
    if a >= 1000:
        return f"{v:,.0f}".replace(",", " ")
    if a >= 1:
        return f"{v:,.2f}".replace(",", " ")
    if a >= 0.01:
        return f"{v:.4f}"
    return f"{v:.8f}"

def _pct(value):
    try:
        return f"{float(value) * 100:.1f}%"
    except (TypeError, ValueError):
        return "—"

def _decision_style(decision):
    kind = td.classify_decision(decision)
    return DECISION_LABEL[kind], {"buy": COLOR_BUY, "sell": COLOR_SELL}.get(kind, COLOR_HOLD)

def _brand(e, footer=""):
    e.set_author(name=BRAND, icon_url=ICON_URL)
    e.set_footer(text=footer or BRAND)
    return e

def _target_delta(row):
    try:
        cur, fut = float(row["current"]), float(row["future"])
        return f"{(fut / cur - 1.0) * 100:+.2f}%" if cur else ""
    except (KeyError, TypeError, ValueError):
        return ""

def _table(headers, rows, align):
    widths = [max(len(str(h)), *(len(str(r[i])) for r in rows)) for i, h in enumerate(headers)]

    def line(cells):
        return "  ".join(
            str(c).ljust(widths[i]) if align[i] == "l" else str(c).rjust(widths[i])
            for i, c in enumerate(cells)
        ).rstrip()

    sep = "  ".join("─" * w for w in widths)
    return "```\n" + "\n".join([line(headers), sep] + [line(r) for r in rows]) + "\n```"

def signal_embed(row):
    label, color = _decision_style(row.get("decision", ""))
    cur = row.get("currency", "") or ""
    e = discord.Embed(
        title=f"{row.get('asset', '?')} — {label}",
        description="Új jelzés az AI Crypto Trackerből.",
        color=color,
    )
    e.add_field(name="Ár", value=f"**{_fmt(row.get('current'))}** {cur}".strip(), inline=True)
    delta = _target_delta(row)
    e.add_field(name="AI célár (1 óra)", value=f"{_fmt(row.get('future'))} {cur}  `{delta}`".strip(), inline=True)
    e.add_field(name="RSI", value=_fmt(row.get("rsi")), inline=True)
    if row.get("next_up_prob") is not None:
        e.add_field(name="Esély emelkedésre", value=_pct(row.get("next_up_prob")), inline=True)
    if row.get("accuracy") is not None:
        e.add_field(name="Modell pontosság", value=_pct(row.get("accuracy")), inline=True)
    if row.get("vol_ann") is not None:
        e.add_field(name="Volatilitás (év.)", value=f"{float(row['vol_ann']):.1f}%", inline=True)
    ts = row.get("ts")
    return _brand(e, f"{BRAND} · {ts}" if ts else BRAND)

async def latest_tracker_release():
    import aiohttp
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as s:
            async with s.get(
                f"https://api.github.com/repos/{TRACKER_REPO}/releases/latest",
                headers={"Accept": "application/vnd.github+json", "User-Agent": "crypto-signal-bot"},
            ) as r:
                if r.status != 200:
                    return None
                return await r.json()
    except Exception:
        return None

intents = discord.Intents.default()

class SignalBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)
        self._last_id = 0

    async def setup_hook(self):
        if config.GUILD_ID:
            guild = discord.Object(id=config.GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("%d slash parancs szinkronizálva a szerverre.", len(synced))
        else:
            synced = await self.tree.sync()
            log.info("%d slash parancs globálisan szinkronizálva (akár 1 óra is lehet).", len(synced))

        self._last_id = self._load_state()

        if config.SIGNALS_CHANNEL_ID:
            if not self.poll_signals.is_running():
                self.poll_signals.start()
            log.info("Jelzésfigyelő elindítva (%ss, csatorna: %s).",
                     config.POLL_SECONDS, config.SIGNALS_CHANNEL_ID)
        else:
            log.info("SIGNALS_CHANNEL_ID nincs megadva → automatikus posztolás kikapcsolva.")

    def _state_file(self):
        config.STATE_DIR.mkdir(parents=True, exist_ok=True)
        return config.STATE_DIR / "last_signal_id.txt"

    def _load_state(self):
        f = self._state_file()
        if f.is_file():
            try:
                return int((f.read_text(encoding="utf-8").strip() or "0"))
            except ValueError:
                pass
        baseline = td.max_signal_id()
        self._save_state(baseline)
        return baseline

    def _save_state(self, val):
        try:
            self._state_file().write_text(str(int(val)), encoding="utf-8")
        except OSError:
            pass

    async def on_ready(self):
        log.info("Bejelentkezve mint %s (ID: %s)", self.user, self.user.id)
        await self.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="a piacot · /arak"))

    @tasks.loop(seconds=config.POLL_SECONDS)
    async def poll_signals(self):
        channel = self.get_channel(config.SIGNALS_CHANNEL_ID)
        if channel is None:
            try:
                channel = await self.fetch_channel(config.SIGNALS_CHANNEL_ID)
            except discord.DiscordException:
                return

        rows = td.rows_after(self._last_id)
        if not rows:
            return

        max_id = self._last_id
        for row in rows:
            max_id = max(max_id, int(row.get("id", 0)))
            if td.classify_decision(row.get("decision", "")) in ("buy", "sell"):
                try:
                    await channel.send(embed=signal_embed(row))
                except discord.DiscordException as ex:
                    log.warning("Nem sikerült posztolni (%s): %s", row.get("asset"), ex)

        if max_id > self._last_id:
            self._last_id = max_id
            self._save_state(max_id)

    @poll_signals.before_loop
    async def _before_poll(self):
        await self.wait_until_ready()

bot = SignalBot()

def _no_data_embed():
    e = discord.Embed(
        title="Nincs adat",
        description=(
            "Nem találom a tracker adatbázisát, vagy még nincs benne elemzés.\n"
            f"Várt hely: `{td.DB_PATH}`\n"
            "Futtass előbb egy elemzést az AI Crypto Trackerben."
        ),
        color=COLOR_INFO,
    )
    return _brand(e)

@bot.tree.command(name="arak", description="Egy eszköz vagy az összes eszköz legfrissebb elemzése")
@app_commands.describe(eszkoz="Pl. Bitcoin, Ethereum, Apple — üresen hagyva az összes eszköz legutóbbi elemzése")
async def arak(interaction: discord.Interaction, eszkoz: str = ""):
    if eszkoz.strip():
        row = td.latest_for_asset(eszkoz.strip())
        if not row:
            await interaction.response.send_message(
                f"Nincs találat erre: **{eszkoz}**.", ephemeral=True)
            return
        await interaction.response.send_message(embed=signal_embed(row))
        return

    rows = td.latest_each_asset(limit=25)
    if not rows:
        await interaction.response.send_message(embed=_no_data_embed(), ephemeral=True)
        return
    table = []
    for row in rows:
        label, _ = _decision_style(row.get("decision", ""))
        table.append([
            (row.get("asset") or "?")[:18],
            _fmt(row.get("current")),
            row.get("currency", "") or "",
            _target_delta(row),
            _fmt(row.get("rsi")),
            label,
        ])
    counts = {k: sum(1 for r in rows if td.classify_decision(r.get("decision", "")) == k) for k in DECISION_LABEL}
    e = discord.Embed(
        title="Legfrissebb elemzések",
        description=_table(["Eszköz", "Ár", "", "AI 1h", "RSI", "Döntés"], table, "lrlrrl"),
        color=COLOR_INFO,
    )
    e.add_field(name="Vétel", value=str(counts["buy"]), inline=True)
    e.add_field(name="Eladás", value=str(counts["sell"]), inline=True)
    e.add_field(name="Várj", value=str(counts["hold"]), inline=True)
    newest = max((r.get("ts") or "" for r in rows), default="")
    await interaction.response.send_message(embed=_brand(e, f"{BRAND} · legutóbbi elemzés: {newest}"))

@bot.tree.command(name="portfolio", description="A tracker portfóliója (holdings.json) az aktuális árakkal")
async def portfolio(interaction: discord.Interaction):
    holdings = td.load_holdings()
    if not holdings:
        await interaction.response.send_message(
            "A portfólió üres (nincs `holdings.json` vagy nincs benne pozíció).",
            ephemeral=True)
        return
    table = []
    total_by_cur = {}
    for asset, amount in sorted(holdings.items()):
        row = td.latest_for_asset(asset)
        if row and row.get("current") is not None:
            cur = row.get("currency", "") or ""
            value = float(row["current"]) * amount
            total_by_cur[cur] = total_by_cur.get(cur, 0.0) + value
            table.append([asset[:18], f"{amount:g}", _fmt(row["current"]), _fmt(value), cur])
        else:
            table.append([asset[:18], f"{amount:g}", "—", "—", ""])
    e = discord.Embed(
        title="Portfólió",
        description=_table(["Eszköz", "Menny.", "Ár", "Érték", ""], table, "lrrrl"),
        color=COLOR_INFO,
    )
    for c, v in total_by_cur.items():
        e.add_field(name=f"Becsült összérték{f' ({c})' if c else ''}", value=f"**{_fmt(v)}** {c}".strip(), inline=True)
    await interaction.response.send_message(embed=_brand(e))

@bot.tree.command(name="kedvencek", description="A trackerben megjelölt kedvenc eszközök")
async def kedvencek(interaction: discord.Interaction):
    favs = td.load_favorites()
    if not favs:
        await interaction.response.send_message(
            "Nincs kedvenc megjelölve (`favorites.json`).", ephemeral=True)
        return
    table = []
    for f in favs:
        row = td.latest_for_asset(f)
        if row:
            label, _ = _decision_style(row.get("decision", ""))
            table.append([f[:18], _fmt(row.get("current")), row.get("currency", "") or "", label])
        else:
            table.append([f[:18], "—", "", "—"])
    e = discord.Embed(
        title="Kedvencek",
        description=_table(["Eszköz", "Ár", "", "Döntés"], table, "lrll"),
        color=COLOR_INFO,
    )
    await interaction.response.send_message(embed=_brand(e))

@bot.tree.command(name="elozmenyek", description="Korábbi elemzések az adatbázisból")
@app_commands.describe(eszkoz="Szűrés eszközre (üresen: minden eszköz)", darab="Hány sor (1–20)")
async def elozmenyek(interaction: discord.Interaction, eszkoz: str = "", darab: int = 10):
    darab = max(1, min(20, darab))
    rows = td.history(eszkoz.strip(), limit=darab)
    if not rows:
        await interaction.response.send_message(embed=_no_data_embed(), ephemeral=True)
        return
    table = []
    for row in rows:
        label, _ = _decision_style(row.get("decision", ""))
        table.append([
            (row.get("ts") or "")[5:16],
            (row.get("asset") or "?")[:16],
            _fmt(row.get("current")),
            _fmt(row.get("rsi")),
            label,
        ])
    title = f"Előzmények — {eszkoz}" if eszkoz.strip() else "Előzmények"
    e = discord.Embed(
        title=title,
        description=_table(["Idő", "Eszköz", "Ár", "RSI", "Döntés"], table, "llrrl"),
        color=COLOR_INFO,
    )
    await interaction.response.send_message(embed=_brand(e))

@bot.tree.command(name="info", description="A bot rövid súgója és a tracker legfrissebb verziója")
async def info(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    e = discord.Embed(
        title="Crypto Signal Bot",
        description=(
            "Az **AI Crypto Tracker** helyi adatait olvasom, és új "
            "VÉTEL / ELADÁS döntésnél automatikusan jelzek a beállított csatornába."
        ),
        color=COLOR_INFO,
    )
    e.add_field(
        name="Parancsok",
        value=(
            "`/arak [eszkoz]` — legfrissebb elemzés(ek)\n"
            "`/portfolio` — portfólió aktuális értékkel\n"
            "`/kedvencek` — kedvencek a legutóbbi döntéssel\n"
            "`/elozmenyek [eszkoz] [darab]` — korábbi elemzések"
        ),
        inline=False,
    )
    auto = f"bekapcsolva, {config.POLL_SECONDS} mp-enként" if config.SIGNALS_CHANNEL_ID else "kikapcsolva (nincs SIGNALS_CHANNEL_ID)"
    e.add_field(name="Automatikus jelzések", value=auto, inline=True)
    rel = await latest_tracker_release()
    if rel:
        name = rel.get("name") or rel.get("tag_name") or "?"
        e.add_field(name="Tracker legfrissebb kiadása", value=f"[{name}]({rel.get('html_url')})", inline=True)
    else:
        e.add_field(name="Tracker kiadások", value=f"[GitHub](https://github.com/{TRACKER_REPO}/releases)", inline=True)
    await interaction.followup.send(embed=_brand(e), ephemeral=True)

def main():
    if not config.TOKEN:
        raise SystemExit(
            "Hiányzik a DISCORD_TOKEN! Másold a .env.example-t .env néven és töltsd ki."
        )
    bot.run(config.TOKEN, log_handler=None)

if __name__ == "__main__":
    main()
