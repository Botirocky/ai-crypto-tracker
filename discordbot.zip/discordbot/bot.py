"""Crypto Signal Bot — az AI Crypto Tracker jelzéseit posztolja Discordra,
és interaktív slash parancsokat ad a tracker helyi adataiból.

Indítás:  python bot.py   (a .venv-ből)  ·  vagy:  ./run.sh
"""
import logging

import discord
from discord import app_commands
from discord.ext import commands, tasks

import config
import tracker_data as td

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("crypto-signal-bot")

# Embed színek (a tracker / weboldal palettájából)
COLOR_BUY = 0x23E87A
COLOR_SELL = 0xFF5D73
COLOR_HOLD = 0xFFCB45
COLOR_INFO = 0x5865F2


def _fmt(value):
    """Ár olvasható formázása a nagyságrendtől függően."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "—"
    a = abs(v)
    if a >= 1000:
        return f"{v:,.0f}"
    if a >= 1:
        return f"{v:,.2f}"
    if a >= 0.01:
        return f"{v:.4f}"
    return f"{v:.8f}"


def _pct(value):
    try:
        return f"{float(value) * 100:.1f}%"
    except (TypeError, ValueError):
        return "—"


def _decision_style(decision):
    kind = td.classify_decision(decision)
    if kind == "buy":
        return "📈", COLOR_BUY
    if kind == "sell":
        return "📉", COLOR_SELL
    return "⏳", COLOR_HOLD


def signal_embed(row):
    """Egy elemzési sorból gazdag jelzés-embed."""
    emoji, color = _decision_style(row.get("decision", ""))
    cur = row.get("currency", "") or ""
    e = discord.Embed(
        title=f"{emoji}  {row.get('asset', '?')}",
        description=f"**Döntés:** {row.get('decision', '—')}",
        color=color,
    )
    e.add_field(name="💰 Ár", value=f"{_fmt(row.get('current'))} {cur}".strip(), inline=True)
    e.add_field(name="🎯 AI célár", value=f"{_fmt(row.get('future'))} {cur}".strip(), inline=True)
    e.add_field(name="📐 RSI", value=_fmt(row.get("rsi")), inline=True)
    if row.get("next_up_prob") is not None:
        e.add_field(name="🤖 Esély fel", value=_pct(row.get("next_up_prob")), inline=True)
    if row.get("accuracy") is not None:
        e.add_field(name="🎲 Modell pontosság", value=_pct(row.get("accuracy")), inline=True)
    ts = row.get("ts")
    e.set_footer(text=f"AI Crypto Tracker · {ts}" if ts else "AI Crypto Tracker")
    return e


# Slash parancsokhoz nem kell privilegizált intent.
intents = discord.Intents.default()


class SignalBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)
        self._last_id = 0

    async def setup_hook(self):
        # Slash parancsok szinkronizálása
        if config.GUILD_ID:
            guild = discord.Object(id=config.GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("%d slash parancs szinkronizálva a szerverre.", len(synced))
        else:
            synced = await self.tree.sync()
            log.info("%d slash parancs globálisan szinkronizálva (akár 1 óra is lehet).", len(synced))

        # Hol tartunk a jelzések posztolásában (induláskor a jelenlegi maximumtól)
        self._last_id = self._load_state()

        if config.SIGNALS_CHANNEL_ID:
            if not self.poll_signals.is_running():
                self.poll_signals.start()
            log.info("Jelzésfigyelő elindítva (%ss, csatorna: %s).",
                     config.POLL_SECONDS, config.SIGNALS_CHANNEL_ID)
        else:
            log.info("SIGNALS_CHANNEL_ID nincs megadva → automatikus posztolás kikapcsolva.")

    # ── állapot (meddig jutott) ──────────────────────────────────────────
    def _state_file(self):
        config.STATE_DIR.mkdir(parents=True, exist_ok=True)
        return config.STATE_DIR / "last_signal_id.txt"

    def _load_state(self):
        f = self._state_file()
        if f.is_file():
            try:
                return int((f.read_text(encoding="utf-8").strip() or "0"))
            except ValueError:
                pass
        # Első indítás: a jelenlegi maximumtól figyelünk (nincs visszamenőleges dömping)
        baseline = td.max_signal_id()
        self._save_state(baseline)
        return baseline

    def _save_state(self, val):
        try:
            self._state_file().write_text(str(int(val)), encoding="utf-8")
        except OSError:
            pass

    async def on_ready(self):
        log.info("Bejelentkezve mint %s (ID: %s)", self.user, self.user.id)
        await self.change_presence(activity=discord.Game(name="/arak · kripto jelzések"))

    # ── automatikus jelzésfigyelő ────────────────────────────────────────
    @tasks.loop(seconds=config.POLL_SECONDS)
    async def poll_signals(self):
        channel = self.get_channel(config.SIGNALS_CHANNEL_ID)
        if channel is None:
            try:
                channel = await self.fetch_channel(config.SIGNALS_CHANNEL_ID)
            except discord.DiscordException:
                return

        rows = td.rows_after(self._last_id)
        if not rows:
            return

        max_id = self._last_id
        for row in rows:
            max_id = max(max_id, int(row.get("id", 0)))
            if td.classify_decision(row.get("decision", "")) in ("buy", "sell"):
                try:
                    await channel.send(embed=signal_embed(row))
                except discord.DiscordException as ex:
                    log.warning("Nem sikerült posztolni (%s): %s", row.get("asset"), ex)

        if max_id > self._last_id:
            self._last_id = max_id
            self._save_state(max_id)

    @poll_signals.before_loop
    async def _before_poll(self):
        await self.wait_until_ready()


bot = SignalBot()


def _no_data_embed():
    return discord.Embed(
        title="ℹ️ Nincs adat",
        description=(
            "Nem találom a tracker adatbázisát, vagy még nincs benne elemzés.\n"
            f"Várt hely: `{td.DB_PATH}`\n"
            "Futtass előbb egy elemzést az AI Crypto Trackerben."
        ),
        color=COLOR_INFO,
    )


# ─────────────────────────── Slash parancsok ───────────────────────────
@bot.tree.command(name="arak", description="Egy eszköz vagy az összes eszköz legfrissebb elemzése")
@app_commands.describe(eszkoz="Pl. BTC, ETH, AAPL — üresen hagyva az összes eszköz legutóbbi elemzése")
async def arak(interaction: discord.Interaction, eszkoz: str = ""):
    if eszkoz.strip():
        row = td.latest_for_asset(eszkoz.strip())
        if not row:
            await interaction.response.send_message(
                f"Nincs találat erre: **{eszkoz}**.", ephemeral=True)
            return
        await interaction.response.send_message(embed=signal_embed(row))
        return

    rows = td.latest_each_asset(limit=25)
    if not rows:
        await interaction.response.send_message(embed=_no_data_embed(), ephemeral=True)
        return
    e = discord.Embed(title="📊 Legfrissebb elemzések", color=COLOR_INFO)
    for row in rows:
        emoji, _ = _decision_style(row.get("decision", ""))
        cur = row.get("currency", "") or ""
        e.add_field(
            name=f"{emoji} {row.get('asset', '?')}",
            value=f"{_fmt(row.get('current'))} {cur} · RSI {_fmt(row.get('rsi'))}".strip(),
            inline=True,
        )
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="portfolio", description="A tracker portfóliója (holdings.json) az aktuális árakkal")
async def portfolio(interaction: discord.Interaction):
    holdings = td.load_holdings()
    if not holdings:
        await interaction.response.send_message(
            "A portfólió üres (nincs `holdings.json` vagy nincs benne pozíció).",
            ephemeral=True)
        return
    e = discord.Embed(title="💼 Portfólió", color=COLOR_INFO)
    total_by_cur = {}
    for asset, amount in sorted(holdings.items()):
        row = td.latest_for_asset(asset)
        if row and row.get("current") is not None:
            cur = row.get("currency", "") or ""
            value = float(row["current"]) * amount
            total_by_cur[cur] = total_by_cur.get(cur, 0.0) + value
            e.add_field(
                name=asset,
                value=f"{amount:g} db · {_fmt(value)} {cur}".strip(),
                inline=True,
            )
        else:
            e.add_field(name=asset, value=f"{amount:g} db · (nincs ár)", inline=True)
    if total_by_cur:
        e.description = "**Becsült összérték:** " + " · ".join(
            f"{_fmt(v)} {c}".strip() for c, v in total_by_cur.items())
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="kedvencek", description="A trackerben megjelölt kedvenc eszközök")
async def kedvencek(interaction: discord.Interaction):
    favs = td.load_favorites()
    if not favs:
        await interaction.response.send_message(
            "Nincs kedvenc megjelölve (`favorites.json`).", ephemeral=True)
        return
    e = discord.Embed(
        title="⭐ Kedvencek",
        description="\n".join(f"• {f}" for f in favs),
        color=COLOR_INFO,
    )
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="elozmenyek", description="Korábbi elemzések az adatbázisból")
@app_commands.describe(eszkoz="Szűrés eszközre (üresen: minden eszköz)", darab="Hány sor (1–20)")
async def elozmenyek(interaction: discord.Interaction, eszkoz: str = "", darab: int = 10):
    darab = max(1, min(20, darab))
    rows = td.history(eszkoz.strip(), limit=darab)
    if not rows:
        await interaction.response.send_message(embed=_no_data_embed(), ephemeral=True)
        return
    lines = []
    for row in rows:
        emoji, _ = _decision_style(row.get("decision", ""))
        cur = row.get("currency", "") or ""
        ts = (row.get("ts") or "")[:16]
        lines.append(
            f"{emoji} **{row.get('asset', '?')}** · {_fmt(row.get('current'))} {cur} "
            f"· RSI {_fmt(row.get('rsi'))} · {ts}".strip())
    title = f"🕘 Előzmények — {eszkoz}" if eszkoz.strip() else "🕘 Előzmények"
    e = discord.Embed(title=title, description="\n".join(lines), color=COLOR_INFO)
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="info", description="A bot rövid súgója")
async def info(interaction: discord.Interaction):
    e = discord.Embed(
        title="🤖 Crypto Signal Bot",
        description=(
            "Az **AI Crypto Tracker** helyi adatait olvasom, és új "
            "VÉTEL/ELADÁS döntésnél automatikusan jelzek a beállított csatornába.\n\n"
            "**Parancsok**\n"
            "• `/arak [eszkoz]` — legfrissebb elemzés(ek)\n"
            "• `/portfolio` — portfólió aktuális értékkel\n"
            "• `/kedvencek` — megjelölt kedvencek\n"
            "• `/elozmenyek [eszkoz] [darab]` — korábbi elemzések\n"
        ),
        color=COLOR_INFO,
    )
    auto = "bekapcsolva" if config.SIGNALS_CHANNEL_ID else "kikapcsolva (nincs SIGNALS_CHANNEL_ID)"
    e.set_footer(text=f"Automatikus jelzések: {auto} · figyelés {config.POLL_SECONDS}s")
    await interaction.response.send_message(embed=e, ephemeral=True)


def main():
    if not config.TOKEN:
        raise SystemExit(
            "Hiányzik a DISCORD_TOKEN! Másold a .env.example-t .env néven és töltsd ki."
        )
    bot.run(config.TOKEN, log_handler=None)


if __name__ == "__main__":
    main()
