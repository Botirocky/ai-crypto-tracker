"""Konfiguráció betöltése a .env fájlból."""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()


def _get_int(key: str):
    """Egész szám beolvasása a környezeti változókból, üres/hibás értéknél None."""
    value = os.getenv(key, "").strip()
    return int(value) if value.lstrip("-").isdigit() else None


# A bot tokenje (Discord Developer Portal -> Bot -> Reset Token)
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()

# Fejlesztéshez: ha megadod, a slash parancsok azonnal frissülnek ezen a szerveren.
GUILD_ID = _get_int("GUILD_ID")

# Csatorna, ahova a bot automatikusan kiposztolja a VÉTEL/ELADÁS jelzéseket.
# Ha üres, az automatikus posztolás ki van kapcsolva (a slash parancsok így is mennek).
SIGNALS_CHANNEL_ID = _get_int("SIGNALS_CHANNEL_ID")

# Milyen gyakran (másodperc) nézze a tracker adatbázisát új jelzésekért. Min. 15s.
POLL_SECONDS = max(15, int(os.getenv("POLL_SECONDS", "60") or "60"))

# Az AI Crypto Tracker adatmappája (felülírható a .env-ben).
TRACKER_DATA_DIR = Path(
    os.getenv("TRACKER_DATA_DIR", "").strip()
    or (Path.home() / ".config" / "ai-cripto-tracker")
)

# A bot saját állapotmappája (meddig jutott a jelzések posztolásában).
STATE_DIR = Path(__file__).resolve().parent / ".state"
