"""Konfiguráció betöltése a .env fájlból."""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

def _get_int(key: str):
    """Egész szám beolvasása a környezeti változókból, üres/hibás értéknél None."""
    value = os.getenv(key, "").strip()
    return int(value) if value.lstrip("-").isdigit() else None

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()

GUILD_ID = _get_int("GUILD_ID")

SIGNALS_CHANNEL_ID = _get_int("SIGNALS_CHANNEL_ID")

POLL_SECONDS = max(15, int(os.getenv("POLL_SECONDS", "60") or "60"))

TRACKER_DATA_DIR = Path(
    os.getenv("TRACKER_DATA_DIR", "").strip()
    or (Path.home() / ".config" / "ai-cripto-tracker")
)

STATE_DIR = Path(__file__).resolve().parent / ".state"
