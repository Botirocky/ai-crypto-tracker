"""Az AI Crypto Tracker helyi adatainak olvasása — KIZÁRÓLAG OLVASÁSRA.

A tracker a ``~/.config/ai-cripto-tracker`` mappába ír:
  - ``history.sqlite3``  → ``analysis_log`` tábla (minden elemzés)
  - ``favorites.json``   → kedvenc eszközök
  - ``holdings.json``    → portfólió (eszköz → mennyiség)

Feltételezzük, hogy a bot ugyanazon a gépen fut, ahol a tracker.
"""
import json
import sqlite3

import config

DB_PATH = config.TRACKER_DATA_DIR / "history.sqlite3"
FAVORITES_PATH = config.TRACKER_DATA_DIR / "favorites.json"
HOLDINGS_PATH = config.TRACKER_DATA_DIR / "holdings.json"


def _connect():
    """Csak olvasható kapcsolat (nem hoz létre adatbázist, ha még nincs)."""
    if not DB_PATH.is_file():
        return None
    try:
        conn = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True, timeout=5)
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error:
        return None


def classify_decision(decision: str) -> str:
    """'buy' | 'sell' | 'hold' a döntés szövege alapján (HU/EN/DE)."""
    d = (decision or "").upper()
    if "📈" in d or any(k in d for k in ("VÉTEL", "VETEL", "BUY", "KAUF")):
        return "buy"
    if "⚠️" in d or "📉" in d or any(k in d for k in ("ELADÁS", "ELADAS", "SELL", "VERKAUF")):
        return "sell"
    return "hold"


def max_signal_id() -> int:
    conn = _connect()
    if conn is None:
        return 0
    try:
        row = conn.execute("SELECT MAX(id) AS m FROM analysis_log").fetchone()
        return int(row["m"]) if row and row["m"] is not None else 0
    except sqlite3.Error:
        return 0
    finally:
        conn.close()


def rows_after(after_id: int, limit: int = 200):
    """Az ``after_id`` utáni sorok növekvő sorrendben."""
    conn = _connect()
    if conn is None:
        return []
    try:
        cur = conn.execute(
            "SELECT * FROM analysis_log WHERE id > ? ORDER BY id ASC LIMIT ?",
            (after_id, limit),
        )
        return [dict(r) for r in cur.fetchall()]
    except sqlite3.Error:
        return []
    finally:
        conn.close()


def latest_for_asset(asset: str):
    conn = _connect()
    if conn is None:
        return None
    try:
        cur = conn.execute(
            "SELECT * FROM analysis_log WHERE asset LIKE ? ORDER BY id DESC LIMIT 1",
            (f"%{asset}%",),
        )
        row = cur.fetchone()
        return dict(row) if row else None
    except sqlite3.Error:
        return None
    finally:
        conn.close()


def latest_each_asset(limit: int = 25):
    """Eszközönként a legutóbbi elemzés."""
    conn = _connect()
    if conn is None:
        return []
    try:
        cur = conn.execute(
            """SELECT a.* FROM analysis_log a
               JOIN (SELECT asset, MAX(id) AS mid FROM analysis_log GROUP BY asset) m
                 ON a.id = m.mid
               ORDER BY a.asset ASC LIMIT ?""",
            (limit,),
        )
        return [dict(r) for r in cur.fetchall()]
    except sqlite3.Error:
        return []
    finally:
        conn.close()


def history(asset: str = "", limit: int = 10):
    conn = _connect()
    if conn is None:
        return []
    try:
        if asset.strip():
            cur = conn.execute(
                "SELECT * FROM analysis_log WHERE asset LIKE ? ORDER BY id DESC LIMIT ?",
                (f"%{asset}%", limit),
            )
        else:
            cur = conn.execute(
                "SELECT * FROM analysis_log ORDER BY id DESC LIMIT ?", (limit,)
            )
        return [dict(r) for r in cur.fetchall()]
    except sqlite3.Error:
        return []
    finally:
        conn.close()


def _load_json(path):
    try:
        if path.is_file():
            return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    return None


def load_favorites():
    data = _load_json(FAVORITES_PATH)
    if isinstance(data, list):
        return [str(x) for x in data]
    if isinstance(data, dict):
        # toleráljuk a {"favorites": [...]} formát is
        fav = data.get("favorites")
        if isinstance(fav, list):
            return [str(x) for x in fav]
    return []


def load_holdings():
    data = _load_json(HOLDINGS_PATH)
    out = {}
    if isinstance(data, dict):
        for k, v in data.items():
            try:
                amount = float(v)
            except (TypeError, ValueError):
                continue
            if amount > 0:
                out[str(k)] = amount
    return out
