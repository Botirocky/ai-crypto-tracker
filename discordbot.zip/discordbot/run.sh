#!/usr/bin/env bash
# A botot mindig a saját venv-jéből indítja, tiszta Python-környezettel
# (kiszűri a snap/VS Code által esetleg beszivárgó PYTHONHOME/PYTHONPATH-t).
cd "$(dirname "$0")" || exit 1
exec env -u PYTHONHOME -u PYTHONPATH .venv/bin/python bot.py
