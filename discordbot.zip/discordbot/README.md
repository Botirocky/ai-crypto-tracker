# Crypto Signal Bot

Önálló Discord bot az **AI Crypto Tracker**hez. A tracker helyi adatait
(`history.sqlite3`, `favorites.json`, `holdings.json`) **csak olvasva** használja,
és két dolgot csinál:

1. **Automatikus jelzések** — háttérben figyeli az adatbázist, és minden új
   **VÉTEL / ELADÁS** döntésnél kiposztol egy embedet a megadott csatornába.
2. **Slash parancsok** — interaktív lekérdezések a tracker adataiból.

> Ez egy **különálló** bot, nem a `discord-bot/` mappában lévő moderációs bot.
> Feltételezi, hogy ugyanazon a gépen fut, ahol a tracker.

## Parancsok

| Parancs | Mit csinál |
|---------|-----------|
| `/arak [eszkoz]` | Egy eszköz vagy az összes eszköz legfrissebb elemzése |
| `/portfolio` | A `holdings.json` portfólió aktuális értékkel |
| `/kedvencek` | A megjelölt kedvenc eszközök |
| `/elozmenyek [eszkoz] [darab]` | Korábbi elemzések az adatbázisból |
| `/info` | Rövid súgó |

## 1. Bot a Discordon

1. https://discord.com/developers/applications → **New Application**
2. **Bot** → **Reset Token** → másold ki (ez megy a `.env`-be).
   *(Privilegizált intent NEM kell — a slash parancsok intent nélkül működnek.)*
3. **OAuth2 → URL Generator**: Scopes: `bot`, `applications.commands`;
   Bot Permissions: `Send Messages`, `Embed Links`, `Read Message History`.
   A generált linkkel hívd meg a botot a szerveredre.

## 2. Telepítés

```bash
cd ~/Dokumentumok/projectek/crypto-signal-bot
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
```

## 3. Konfiguráció

```bash
cp .env.example .env
```

Töltsd ki legalább a `DISCORD_TOKEN`-t. Az automatikus jelzésekhez add meg a
`SIGNALS_CHANNEL_ID`-t is (jobb klikk a csatornára → „ID másolása", fejlesztői mód mellett).
Fejlesztéshez érdemes a `GUILD_ID` is, hogy a slash parancsok azonnal megjelenjenek.

## 4. Indítás

```bash
./run.sh
# vagy:
.venv/bin/python bot.py
```

A `run.sh` a saját venv-ből, tiszta környezettel indít (kiszűri a snap/VS Code
által esetleg beszivárgó `PYTHONHOME`/`PYTHONPATH`-t).

## Megjegyzések

- Induláskor **nem** dömpingeli ki a korábbi jelzéseket: a `.state/last_signal_id.txt`
  fájlban jegyzi, meddig jutott, így újraindítás után sem posztol duplán.
- Ha a `SIGNALS_CHANNEL_ID` üres, csak a slash parancsok mennek (automatikus posztolás kikapcsolva).
- Python 3.13+ esetén discord.py **2.5+** kell (a 2.7.x tesztelt 3.14-en).
